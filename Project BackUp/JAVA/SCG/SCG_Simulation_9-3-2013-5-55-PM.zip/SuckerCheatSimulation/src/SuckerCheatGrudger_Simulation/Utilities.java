/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package SuckerCheatGrudger_Simulation;
import SimulationOutputDisplayViaSwingWorker.*;
/**
 *
 * @author Sukrit
 */
public class Utilities {

    static String removePercentageSign(String a){
        
        return a.substring(0, a.length()-1);
        
    }
}

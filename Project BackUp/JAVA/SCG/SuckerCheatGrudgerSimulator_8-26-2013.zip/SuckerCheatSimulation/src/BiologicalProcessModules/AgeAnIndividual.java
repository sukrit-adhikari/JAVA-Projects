package BiologicalProcessModules;
import SuckerCheatGrudger_Simulation.Individual;
import SuckerCheatGrudger_Simulation.SimulationParameters;
       

public class AgeAnIndividual {

   // public Float getNewHealth(Integer currentTime, Integer timeOfBirth, SimulationParameters sP, Float currentHealth){
        
     //   Float newHealth;
        
        //newHealth = 
        
   // }
    
}

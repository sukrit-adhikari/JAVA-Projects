/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package calculator;

/**
 *
 * @author Sukrit
 */
public class Calculator  {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       
         calculator.CalculatorForm calc=new calculator.CalculatorForm();
          calc.setSize(380,310);
          calc.setVisible(true);
          calc.setResizable(false);
                  
    }
}
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package CrawlerHost;

/**
 *
 * @author Sukrit
 */
public class DomainDetails {
 
    String ipAddress;
    String domainName;
    


}

